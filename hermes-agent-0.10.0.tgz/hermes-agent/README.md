<div align="center">

# hermes-agent-helm/hermes-agent

<img height="240" src="https://raw.githubusercontent.com/jyje/hermes-agent-helm/main/docs/images/hermes-agent-helm.png" alt="Kubernetes × Hermes Agent"/>

</div>

👩🏻‍💻 A Helm chart to run Hermes Agent on Kubernetes, community-powered, lightweight

Run [Hermes Agent](https://github.com/NousResearch/hermes-agent) — a multi-provider LLM agent framework — on Kubernetes. Configure any provider Hermes supports (OpenAI, Anthropic, Gemini, OpenRouter, NVIDIA, or any OpenAI-compatible proxy such as LiteLLM/vLLM) entirely via values.yaml, with a built-in helm test health check.

[![GitHub](https://img.shields.io/badge/GitHub-jyje%2Fhermes--agent--helm-181717?logo=github)](https://github.com/jyje/hermes-agent-helm) [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/jyje/hermes-agent-helm/blob/main/LICENSE) ![Version: 0.10.0](https://img.shields.io/badge/Version-0.10.0-informational?style=flat) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat) ![AppVersion: v2026.7.20](https://img.shields.io/badge/AppVersion-v2026.7.20-informational?style=flat)

[English](README.md) · [한국어](README-ko.md)

## TL;DR

```bash
# OCI (recommended)
helm upgrade --install hermes-agent \
  oci://ghcr.io/jyje/hermes-agent-helm/hermes-agent --version 0.10.0 \
  --namespace hermes-agent --create-namespace \
  --set-string env.OPENAI_API_KEY='sk-...' --wait
```

```bash
# Classic Helm repo
helm repo add hermes-agent https://jyje.github.io/hermes-agent-helm
helm repo update
helm upgrade --install hermes-agent hermes-agent/hermes-agent \
  --namespace hermes-agent --create-namespace \
  --set-string env.OPENAI_API_KEY='sk-...' --wait
```

- **ArgoCD** — ready-to-apply `Application` manifests, one per provider/messenger
  combo: [`examples/argocd/`](../../examples/argocd/).
- **GitOps without committing real secrets** — SealedSecret + `extraEnvFrom`
  walkthrough: [`examples/argocd/` § SealedSecret](../../examples/argocd/#sealedsecret-walkthrough-nvidia-nim--discord).
- **Agent team** — run multiple instances that hand off by `@mention` over a shared Discord channel:
  [`examples/argocd/hermes-collab-pair.yaml`](../../examples/argocd/hermes-collab-pair.yaml),
  see [Teams](../../docs/teams.md) + [Collaboration guide](../../docs/collaboration.md).

## Configure your provider

Set `config.model.provider` to a built-in key, supply its key under `env`:

| Provider | `config.model.provider` | Key env var | Example |
| --- | --- | --- | --- |
| OpenAI | `openai-api` | `OPENAI_API_KEY` | [`values-openai.yaml`](values-openai.yaml) |
| Anthropic (Claude) | `anthropic` | `ANTHROPIC_API_KEY` | [`values-anthropic.yaml`](values-anthropic.yaml) |
| Google Gemini | `gemini` | `GOOGLE_API_KEY` | [`values-gemini.yaml`](values-gemini.yaml) |
| Google Vertex AI | `vertex` | none — OAuth2 tokens auto-minted from a mounted service-account JSON (or ADC) | [`values-google-vertex.yaml`](values-google-vertex.yaml) |
| OpenRouter | `openrouter` | `OPENROUTER_API_KEY` | [`values-openrouter.yaml`](values-openrouter.yaml) |
| NVIDIA NIM | `nvidia` | `NVIDIA_API_KEY` | [`values-nvidia-nim-and-discord.yaml`](values-nvidia-nim-and-discord.yaml) |
| GitHub Copilot | `copilot` | `COPILOT_GITHUB_TOKEN` (OAuth device-flow — no API key needed) | [`values-github-copilot.yaml`](values-github-copilot.yaml) |
| Mixture-of-Agents (MoA) | `moa` | depends on the reference/aggregator models in the preset | [`values-moa.yaml`](values-moa.yaml) |
| Custom (LiteLLM / vLLM / LM Studio) | your own id, under `config.providers` | depends on proxy | [`values-litellm.yaml`](values-litellm.yaml) |

> `openai` (no suffix) is **not** a valid provider key — it aliases to
> OpenRouter. Use `openai-api`.

Full provider walkthrough (`--set` examples per provider) and messenger
(Discord/Telegram) setup: see [Provider & messenger setup](#provider--messenger-setup)
below.

## Test

```bash
helm test hermes-agent -n hermes-agent
kubectl logs -n hermes-agent -l app.kubernetes.io/component=test --tail=-1
```

Runs a `hermes doctor`-style health check Job after install. To also verify a
real provider round-trip, see [Advanced testing](#advanced-testing) below.

## Overview

Run [Hermes Agent](https://github.com/NousResearch/hermes-agent) on Kubernetes.
It deploys:

- a **Deployment** (default) or **StatefulSet** (`controller.type`), single
  replica with persistent `HERMES_HOME`, running the image's s6-supervised
  gateway
- a **ConfigMap** holding the partial `config.yaml`
- a **Secret** holding the `.env` (injected via `envFrom`)
- for `controller.type=statefulset`: a headless Service for DNS/governance
  (no inbound port — the gateway is outbound); for `deployment`: a standalone
  PVC instead. Either way, an **optional** ClusterIP Service for the dashboard,
  and an **optional** Ingress in front of it (`ingress.enabled`)
- a **Helm test** Job (`helm test`) that runs a `hermes doctor` style check

The agent's command execution uses the **`local` backend** (commands run inside
the pod; the pod is the sandbox). The `docker` backend is intentionally **not
supported in-cluster** — it requires a Docker daemon/socket, absent on
containerd clusters (MicroK8s / Raspberry Pi) and a security risk to mount.

> Image tags are **date-based** (e.g. `v2026.6.5` == Hermes v0.16.0); the image
> is multi-arch (amd64 + arm64), so it runs on Raspberry Pi clusters.

> **Scaling note.** Hermes is a single-instance personal agent, so this chart
> pins `replicaCount: 1` and there is no multi-replica mode (see the
> `replicaCount` note in the [values table](#values)). To grow, scale *up* (more
> `resources`, larger `persistence.size`) — and when one agent isn't enough, run
> several instances and group them into a **team** that shares one gateway
> channel. See [Hermes teams](../../docs/teams.md).

## Provider & messenger setup

Installing from a local chart checkout (e.g. to try an unreleased change):

```bash
helm upgrade --install hermes-agent ./charts/hermes-agent \
  --namespace hermes-agent --create-namespace \
  --set-string env.OPENAI_API_KEY='sk-...' --wait
```

The chart ships a placeholder `OPENAI_API_KEY`; override it (and `config.model`)
for your provider at install/upgrade time, or supply a values file.

> Tip: using a release name equal to the chart name (`hermes-agent`) keeps
> resource names clean (`hermes-agent-0`) instead of doubling the prefix
> (`hermes-agent-hermes-agent-0`). Or set `fullnameOverride`.

### Install options: LLM provider

This is the main thing you configure at install time — *which* LLM backend
Hermes talks to. (For chat platforms, see
[Messenger integrations](#messenger-integrations-telegram--discord) below.)

- **Built-in provider** — set `config.model.provider` to one of Hermes'
  built-in keys (`openai-api`, `anthropic`, `gemini`, `openrouter`, `nvidia`,
  `deepseek`, `lmstudio`, …) and `config.model.default` to a model id for that
  provider. Supply the matching key under `env` (`OPENAI_API_KEY`,
  `ANTHROPIC_API_KEY`, `GOOGLE_API_KEY`, `NVIDIA_API_KEY`, …).

  ```bash
  # OpenAI
  helm upgrade --install hermes-agent ./charts/hermes-agent -n hermes-agent --create-namespace \
    --set-string config.model.provider=openai-api \
    --set-string config.model.default=gpt-4o-mini \
    --set-string env.OPENAI_API_KEY='sk-...' --wait

  # Gemini
  helm upgrade --install hermes-agent ./charts/hermes-agent -n hermes-agent --create-namespace \
    --set-string config.model.provider=gemini \
    --set-string config.model.default=gemini-2.5-flash \
    --set-string env.GOOGLE_API_KEY='<your-key>' \
    --set-string env.OPENAI_API_KEY=unused --wait

  # NVIDIA NIM (this is the provider CI exercises end-to-end)
  helm upgrade --install hermes-agent ./charts/hermes-agent -n hermes-agent --create-namespace \
    --set-string config.model.provider=nvidia \
    --set-string config.model.default=nvidia/nemotron-3-nano-omni-30b-a3b-reasoning \
    --set-string env.NVIDIA_API_KEY='nvapi-...' \
    --set-string env.OPENAI_API_KEY=unused --wait
  ```

- **Custom OpenAI-compatible provider** (LiteLLM, vLLM, LM Studio, …) — register
  it under `config.providers.<id>` (`base_url`, `key_env`) and point
  `config.model.provider` at that `<id>`. See `values-litellm.yaml` (remote
  proxy) or `values-litellm-k8s.yaml` (in-cluster) in
  ["More examples"](#more-examples).

### Messenger integrations (Telegram / Discord)

`hermes gateway run` (the workload's command) connects whatever chat platforms
it finds **credentials** for — so wiring a messenger is just a matter of
supplying its bot token. The token is sensitive, so put it under `.Values.env`
(rendered into the Secret); the non-secret knobs (allowed users, home channel)
can go under `.Values.extraEnv` (plain env). Setting the token is enough to
**auto-enable** the platform — no `config.yaml` change required.

> **Verification status:** the chart renders the right Secret/env and the agent
> picks the platform up. On trusted CI runs where the `DISCORD_BOT_TOKEN` and
> `DISCORD_HOME_CHANNEL` secrets are configured, CI does a full live
> round-trip — `hermes send` to that channel, then reads the channel back via
> the Discord API to confirm the message arrived — and **fails if it can't be
> verified** (the bot needs *View Channel* + *Read Message History*). Fork PRs
> skip it since secrets aren't exposed. Telegram is still placeholder-only.
> Provide a real bot token to try either in your own cluster.

- **Discord** — create a bot at the
  [Discord Developer Portal](https://discord.com/developers/applications),
  enable the **Message Content Intent**, and invite it to your server.

  ```bash
  helm upgrade --install hermes-agent ./charts/hermes-agent -n hermes-agent --create-namespace \
    --set-string config.model.provider=nvidia \
    --set-string config.model.default=nvidia/nemotron-3-nano-omni-30b-a3b-reasoning \
    --set-string env.NVIDIA_API_KEY='nvapi-...' \
    --set-string env.OPENAI_API_KEY=unused \
    --set-string env.DISCORD_BOT_TOKEN='<bot-token>' --wait
  ```

  Optional non-secret knobs (via `extraEnv`, or `--set`):

  | env var | meaning |
  | --- | --- |
  | `DISCORD_ALLOWED_USERS` | comma-separated user IDs allowed to talk to the bot |
  | `DISCORD_ALLOW_ALL_USERS` | `true` to allow anyone (dev only) |
  | `DISCORD_HOME_CHANNEL` | channel ID for cron / notification delivery |
  | `DISCORD_HOME_CHANNEL_NAME` | display name for that home channel |

- **Telegram** — create a bot via [@BotFather](https://t.me/BotFather) and set
  `env.TELEGRAM_BOT_TOKEN` (optionally `TELEGRAM_HOME_CHANNEL`,
  `TELEGRAM_ALLOWED_USERS` via `extraEnv`).

See `values-anthropic-and-discord.yaml` / `values-openai-and-telegram.yaml` in
["More examples"](#more-examples) for copy-pasteable messenger blocks.

## Login via OAuth device flow (GitHub Copilot)

Some providers issue short-lived OAuth tokens you cannot paste ahead of time —
**GitHub Copilot** is the headline case: its token API rejects PATs and wants a
`gho_`/`ghu_` device-flow token. Set `auth.deviceFlow.enabled=true` and the
chart adds an **`auth-device-login` init container** that performs the
[OAuth 2.0 Device Authorization Grant (RFC 8628)](https://datatracker.ietf.org/doc/html/rfc8628)
at pod startup, surfaces the verification URL + user code for a human to
approve (your Discord home channel by default — phone-friendly), waits, then
persists the resulting token to `HERMES_HOME/.env` exactly where Hermes reads
it. The token lives on the persistent volume, so it is reused across restarts;
re-login only happens when it is missing or revoked (skip-if-valid).

```bash
helm upgrade --install hermes-agent ./charts/hermes-agent -n hermes-agent --create-namespace \
  -f charts/hermes-agent/values-github-copilot.yaml \
  --set-string env.DISCORD_BOT_TOKEN='<bot-token>' --wait
# then approve the prompt posted to Discord (or read it from the logs):
kubectl logs sts/hermes-agent -n hermes-agent -c auth-device-login -f
```

Notes:

- **Requires `persistence.enabled=true`** — without a volume the token is lost
  on restart and you would re-approve every time.
- **`notify`** is `discord` (reuses `DISCORD_BOT_TOKEN` + `DISCORD_HOME_CHANNEL`)
  or `logs` (verification prompt printed to the init container logs only).
- The init container runs as **root** so it can write to any storage class, then
  **chowns** the token file to `auth.deviceFlow.tokenOwner` (default uid/gid
  `10000` — the upstream image's runtime user) so the non-root agent can read it.
- **Catalog model:** `auth.deviceFlow.providers` is a map keyed by provider id
  (each with its own `clientId`/`authHost`/`tokenEnv`/…); `auth.deviceFlow.provider`
  selects which one runs. Only `github-copilot` ships today — add a map entry to
  support another device-flow provider. The Copilot `clientId` default is the
  shared client Hermes upstream itself uses.

## Agent team

Hermes is a **single-instance personal agent** — it does not scale out. Instead,
run several well-managed instances and group them into a team that shares **one
Discord channel** as the context bus. Each agent gets its own bot token, pod, PVC,
and identity; the shared channel is the only thing they have in common.

### How agents hand off by `@mention`

Point every instance at the same `DISCORD_HOME_CHANNEL` (with a different
`DISCORD_BOT_TOKEN` each). Agents hand the conversation to each other by placing
an explicit `<@BOT_USER_ID>` in the **body** of a Discord message — not as a
reply reference. Four env vars make the handoff reliable and prevent infinite
bot-to-bot ping-pong:

| Env var | Recommended value | Why |
| --- | --- | --- |
| `DISCORD_ALLOW_BOTS` | `mentions` | Respond to another bot only when it `@mentions` us. |
| `DISCORD_THREAD_REQUIRE_MENTION` | `true` | In shared threads, fire only on explicit mention. |
| `DISCORD_REPLY_TO_MODE` | `off` | Don't attach a reply-reference — it auto-pings the partner and restarts the loop. |
| `DISCORD_ALLOW_MENTION_REPLIED_USER` | `false` | Never treat an auto reply-ping as a real mention. |

Set these under `env` / `extraEnv` (not under `config` — they are read directly
by the Discord adapter via `os.getenv`).

### Quick start: two agents, one channel

```bash
helm upgrade --install hermes-planner ./charts/hermes-agent \
  --namespace hermes-team --create-namespace \
  -f charts/hermes-agent/values-multi-agent-collab.yaml \
  --set-string env.DISCORD_BOT_TOKEN='<planner-bot-token>' --wait

helm upgrade --install hermes-builder ./charts/hermes-agent \
  --namespace hermes-team \
  -f charts/hermes-agent/values-multi-agent-collab.yaml \
  --set-string env.DISCORD_BOT_TOKEN='<builder-bot-token>' --wait
```

For a declarative roster (3+ agents, GitOps), use an **ArgoCD ApplicationSet**
— adding a teammate becomes a one-line diff. See
[`examples/argocd/hermes-collab-pair.yaml`](../../examples/argocd/hermes-collab-pair.yaml)
and the full guide in [Teams](../../docs/teams.md) + [Collaboration](../../docs/collaboration.md).

## Advanced testing

The [`helm test`](#test) Job (hook `helm.sh/hook: test`) runs `hermes
--version`, verifies the seeded `config.yaml`, checks docker availability
(informational, since the backend is `local`), and runs `hermes doctor`.
Disable it with `--set tests.enabled=false`; make doctor failures fatal with
`--set tests.doctorStrict=true`.

### Verifying a provider end-to-end (`tests.chat.enabled`)

`tests.chat.enabled=true` adds a 5th check: a real `hermes chat` round-trip
using the **same `config`/`env` the release was installed with** (the test Job
mounts the same ConfigMap and Secret as the main workload — no separate
provider key needed), with the **full conversation (prompt + response) printed
to the test Job's logs**. Since `helm test` doesn't take `--set`, flip the flag
with `helm upgrade --reuse-values` and then run the test:

```bash
helm upgrade hermes-agent ./charts/hermes-agent -n hermes-agent \
  --reuse-values --set tests.chat.enabled=true --wait

helm test hermes-agent -n hermes-agent
kubectl logs -n hermes-agent -l app.kubernetes.io/component=test --tail=-1
```

Sample output (NVIDIA NIM, prompt `tests.chat.prompt` default "Just say hi."):

```
[5/5] hermes chat round-trip
--- prompt ---
Just say hi.
--- model: (config default) (timeout 180s) ---
Query: Just say hi.
Initializing agent...
────────────────────────────────────────

╭─ ⚕ Hermes ───────────────────────────────────────────────────────────────────╮
    Hi.
╰──────────────────────────────────────────────────────────────────────────────╯

--- end response ---
```

By default a failed/empty round-trip is **non-fatal** (logged only); set
`tests.chat.failOnError=true` to make it fail the test job (this is what CI
does when an `NVIDIA_API_KEY` secret is available).

For free-tier providers where a single model can be flaky/overloaded, set
`tests.chat.models` to a list of `provider/model` ids — the test Job tries
each in order via `hermes chat -m <id> --provider <config.model.provider>`
(its own `tests.chat.timeout` per attempt) and passes as soon as one succeeds.
This is what CI does (a small pool of free NVIDIA NIM models).

## Configuration model

Hermes reads `$HERMES_HOME/config.yaml` and secrets from the environment as
**partial overrides** on top of its version-specific built-in defaults
(precedence: CLI > `config.yaml` > `.env` > built-in defaults). This chart
follows that model — you only set what you want to change, and never reproduce
the full upstream config (which would drift across Hermes versions).

- **`config.yaml`** — set only override keys under `.Values.config`. It is
  rendered into a ConfigMap and **seeded into `HERMES_HOME`** (the persistent
  volume) by an init container, because Hermes also writes to its home at
  runtime (skills, `auth.json`, self-improvement). `bootstrap.overwrite=true`
  (default) re-seeds on every deploy; set `false` to seed only when absent.
- **Secrets / API keys** — set under `.Values.env`. Rendered into a Secret and
  injected via `envFrom` as environment variables (env wins over `config.yaml`).
  For GitOps, avoid committing real keys in `env` — instead deploy a
  `SealedSecret` (or similar) via `extraResources` and reference the Secret it
  produces with `extraEnvFrom` (applied after the chart's own Secret, so it
  wins). See [`examples/argocd/`](../../examples/argocd/) for a complete
  SealedSecret + `extraEnvFrom` GitOps example.
- **Dashboard Ingress** — the management dashboard (`service.port`, default
  9119) requires `--insecure` to bind beyond `127.0.0.1`, which the upstream
  warns **exposes API keys on the network**. Set `service.enabled: true` and
  `ingress.enabled: true` only behind authentication (e.g. an
  oauth2-proxy/basic-auth Ingress annotation) or on a private network — see
  `ingress.hosts` / `ingress.tls` in `values.yaml`.

## Gateway lifecycle: rollouts, shutdown, and drain

As of image `v2026.7.1` the gateway defaults `agent.restart_drain_timeout` to
**0**: on pod stop (rollout, node drain, `kubectl delete pod`) it interrupts
any in-flight agent run immediately, persists the conversation transcript, and
exits fast. Rollouts are quick by default, and the Kubernetes default
30-second termination grace period is plenty.

To opt into a graceful drain window instead (wait for running agent turns
before interrupting), set both halves — the drain in Hermes config and the
grace period on the pod:

```yaml
config:
  agent:
    restart_drain_timeout: 60    # seconds to wait for in-flight runs
terminationGracePeriodSeconds: 90 # keep WELL ABOVE the drain timeout
```

If the grace period is not comfortably above the drain timeout, the kubelet
SIGKILLs the gateway mid-drain — upstream documents this exact race (against
systemd's `TimeoutStopSec`) as leaving a stale lock that crash-loops the
gateway, which is why its default moved to 0. A drain window also cannot
"save" an unbounded agent turn; treat it as a courtesy, not a guarantee.

> **Scale-to-zero is not applicable in-cluster.** Upstream `v2026.7.1` also
> added scale-to-zero idle detection (dormant-quiesce), but it is exclusive to
> Nous' managed relay deployment: it is enabled by a platform-stamped
> `HERMES_SCALE_TO_ZERO` env (not a user config key), arms only when messaging
> is relay-only with a registered wake URL, and relies on the hosting platform
> suspending the VM. With this chart's direct Discord/Telegram/Slack
> connections it never arms, and Kubernetes would keep the pod Running
> regardless — so the chart deliberately does not expose it.

## Environment variables

This chart only walks through the [provider](#install-options-llm-provider)
and [messenger](#messenger-integrations-telegram--discord) variables needed to
get started — Hermes itself reads many more from its environment. Any of them
can be set the same way as the ones above: secrets under `.Values.env`
(Secret), non-secret knobs under `.Values.extraEnv` (plain env), or via
`extraEnvFrom` for externally-managed secrets (see
[Configuration model](#configuration-model)).

Full reference (kept current with each Hermes release):
**[Environment Variables — Hermes Agent docs](https://hermes-agent.nousresearch.com/docs/reference/environment-variables)**.

A few more commonly-used ones, current as of image `v2026.7.20`:

| Variable | Purpose |
| --- | --- |
| `DEEPSEEK_API_KEY` | DeepSeek provider |
| `ZAI_API_KEY` | Z.AI / GLM provider (built-in key `zai`; `GLM_BASE_URL` picks the Global/China/Coding-Plan endpoint) |
| `AWS_REGION` / `AWS_PROFILE` | Amazon Bedrock provider |
| `AZURE_FOUNDRY_API_KEY` | Microsoft Foundry / Azure OpenAI provider |
| `NOUS_INFERENCE_BASE_URL` | Override the Nous OAuth inference endpoint |
| `HERMES_WRITE_SAFE_ROOT` | Restrict `write_file`/`patch` to these root dirs (OS path separator for multiple) |
| `SLACK_BOT_TOKEN` / `SLACK_APP_TOKEN` | Slack bot (Socket Mode) |
| `MATRIX_HOMESERVER` / `MATRIX_ACCESS_TOKEN` | Matrix homeserver integration |
| `WHATSAPP_CLOUD_PHONE_NUMBER_ID` / `WHATSAPP_CLOUD_ACCESS_TOKEN` | WhatsApp Cloud API |
| `HERMES_MAX_ITERATIONS` | Tool-calling loop limit (default: 90) |
| `HERMES_AGENT_TIMEOUT` | Gateway inactivity timeout (default: 1800s / 30 min) |
| `SESSION_IDLE_MINUTES` | Idle session reset window (default: 1440) |
| `HERMES_TIMEZONE` | IANA timezone override |

> **Not env-configurable:** context compression, fallback providers, and
> provider routing live in `config.yaml` only (under `.Values.config`), with
> no environment variable equivalent.

## More examples

Ready-to-adapt `-f` overlays for common setups, aimed at a small/home cluster
(e.g. a Raspberry Pi / arm64 k3s cluster). All secrets in these files are
**dummy placeholders** — override them at install time with `--set-string` (see
the command in each file's header comment), or via the SealedSecret +
`extraEnvFrom` pattern above.

| File | Model provider | Extras |
| --- | --- | --- |
| [`values-nvidia-nim-and-discord.yaml`](values-nvidia-nim-and-discord.yaml) | NVIDIA NIM | **Discord bot** wired in |
| [`values-github-copilot.yaml`](values-github-copilot.yaml) | GitHub Copilot (`copilot`) | **OAuth device-flow login** + Discord bot |
| [`values-anthropic-and-discord.yaml`](values-anthropic-and-discord.yaml) | Anthropic (Claude) | **Discord bot** wired in |
| [`values-openai-and-telegram.yaml`](values-openai-and-telegram.yaml) | OpenAI (`openai-api`) | **Telegram bot** wired in |
| [`values-openai.yaml`](values-openai.yaml) | OpenAI (`openai-api`) | — |
| [`values-anthropic.yaml`](values-anthropic.yaml) | Anthropic (Claude) | — |
| [`values-gemini.yaml`](values-gemini.yaml) | Google Gemini | — |
| [`values-google-vertex.yaml`](values-google-vertex.yaml) | Google Vertex AI (`vertex`) | **Service-account JSON mounted** via `extraVolumes` (no static API key) |
| [`values-openrouter.yaml`](values-openrouter.yaml) | OpenRouter | — |
| [`values-litellm.yaml`](values-litellm.yaml) | LiteLLM proxy (remote/Ingress) | — |
| [`values-litellm-k8s.yaml`](values-litellm-k8s.yaml) | LiteLLM proxy (in-cluster Service DNS) | — |
| [`values-ingress.yaml`](values-ingress.yaml) | OpenAI (`openai-api`) | **Dashboard Ingress** wired in (basic-auth) |
| [`values-multi-agent-collab.yaml`](values-multi-agent-collab.yaml) | any | **Collaborating pair** — two agents handing off by @mention in a shared Discord channel |
| [`values-team-leader.yaml`](values-team-leader.yaml) + [`values-team-member.yaml`](values-team-member.yaml) | NVIDIA NIM (any works) | **Leader-orchestrated team** — a leader delegates by @mention (star topology) and members share an RWX workspace; see [Teams](../../docs/teams.md) |
| [`values-shared-knowledge.yaml`](values-shared-knowledge.yaml) | Anthropic (Claude) | **Shared RWX PVC** — multiple agents reading/writing to the same knowledge base |

Deploying via ArgoCD instead of plain `helm`/`-f`? See
[`examples/argocd/`](../../examples/argocd/) — it has one Application manifest
per example above, each with its `extraEnvFrom`-based secret pattern.

## Values

| Key | Type | Description | Default |
|-----|------|-------------|---------|
| affinity | object | Affinity rules for Pod scheduling. | `{}` |
| args | list | Arguments appended to `command`. | `["gateway","run"]` |
| auth | object | ------------------------------------------------------------------------- | `{"deviceFlow":{"enabled":false,"forceRelogin":false,"image":{"repository":"python","tag":"3.13-slim"},"notify":"discord","provider":"github-copilot","providers":{"github-copilot":{"authHost":"github.com","clientId":"Ov23li8tweQw6odWQebz","scope":"read:user","tokenEnv":"COPILOT_GITHUB_TOKEN","validateUrl":"https://api.github.com/copilot_internal/v2/token"}},"resources":{},"timeoutSeconds":870,"tokenOwner":{"gid":10000,"uid":10000}}}` |
| auth.deviceFlow.enabled | bool | Bootstrap a provider credential via the OAuth device flow at startup.    When false, the agent uses the static key from `env`/`extraEnvFrom`. | `false` |
| auth.deviceFlow.forceRelogin | bool | Force a fresh login even if a token already exists on the volume. | `false` |
| auth.deviceFlow.image | object | Login image. stdlib-only Python; no extra dependencies are installed. | `{"repository":"python","tag":"3.13-slim"}` |
| auth.deviceFlow.notify | string | Where to deliver the verification URL + user code for human approval.    `discord` reuses the agent's bot creds (DISCORD_BOT_TOKEN +    DISCORD_HOME_CHANNEL from `env`/`extraEnvFrom`). The code is always    also printed to the init container logs as a fallback. | `"discord"` |
| auth.deviceFlow.provider | string | Which provider profile to authenticate. Must be a key under    `providers` below. Only one device-flow login runs at a time. | `"github-copilot"` |
| auth.deviceFlow.providers.github-copilot.authHost | string | Host serving the device-code + token endpoints (GitHub-style paths). | `"github.com"` |
| auth.deviceFlow.providers.github-copilot.clientId | string | OAuth client id for the device grant. The shared opencode/Copilot-CLI    client that Hermes upstream itself uses (hermes_cli/copilot_auth.py). | `"Ov23li8tweQw6odWQebz"` |
| auth.deviceFlow.providers.github-copilot.scope | string | OAuth scope requested in the device grant. | `"read:user"` |
| auth.deviceFlow.providers.github-copilot.tokenEnv | string | .env key Hermes reads this provider's token from (resolution order    COPILOT_GITHUB_TOKEN > GH_TOKEN > GITHUB_TOKEN). | `"COPILOT_GITHUB_TOKEN"` |
| auth.deviceFlow.providers.github-copilot.validateUrl | string | Optional endpoint to verify an existing token is still live; on    401/403 the init container re-runs the login. Empty = skip the check. | `"https://api.github.com/copilot_internal/v2/token"` |
| auth.deviceFlow.resources | object | Resources for the login init container. | `{}` |
| auth.deviceFlow.timeoutSeconds | int | Seconds to wait for the human to authorize before the init container    fails (and retries). Keep below the provider's device-code validity. | `870` |
| auth.deviceFlow.tokenOwner | object | uid/gid that should own the written token file. The login init    container runs as root so it can write to any storage class reliably,    then chowns the token to this owner. Set it to the Hermes runtime uid —    the upstream image's s6-overlay runs the agent as uid/gid 10000 — so the    non-root agent can read the credential. | `{"gid":10000,"uid":10000}` |
| bootstrap.enabled | bool | Seed the rendered config.yaml into HERMES_HOME via an init container. | `true` |
| bootstrap.overwrite | bool | true: overwrite HERMES_HOME/config.yaml with chart content on every    deploy (declarative). false: seed only if it does not already exist    (preserve runtime edits). | `true` |
| command | list | Container entrypoint. The image's DEFAULT CMD is the interactive `hermes` chat, which exits immediately in a pod (no TTY -> EOF -> "Goodbye"), causing a restart loop. So run the long-lived gateway explicitly; inside the s6-overlay image `gateway run` is auto-redirected to the SUPERVISED s6 service (auto-restart on crash). Append `--no-supervise` only if you want to bypass s6. | `["hermes"]` |
| config | object | ------------------------------------------------------------------------- | `{"agent":{"gateway_timeout":1800,"max_turns":90},"model":{"default":"gpt-4o-mini","provider":"openai-api"},"providers":{},"terminal":{"backend":"local"}}` |
| controller | object | ------------------------------------------------------------------------- | `{"type":"deployment"}` |
| controller.type | string | Workload kind: "deployment" or "statefulset". | `"deployment"` |
| env | object | ------------------------------------------------------------------------- | `{"OPENAI_API_KEY":"sk-REPLACE_ME"}` |
| extraEnv | list | Plain (non-secret) env vars injected directly on the container. | `[]` |
| extraEnvFrom | list | Extra envFrom sources (reference existing ConfigMaps/Secrets). | `[]` |
| extraResources | list | Extra raw manifests rendered as-is alongside this chart's resources.    Each entry is `tpl`-rendered, so `{{ .Release.Namespace }}` etc. work, and    may be either an object or a multiline string (see examples/argocd/).    Useful for things this chart doesn't model directly, e.g. a SealedSecret    that a sealed-secrets controller decrypts into a Secret referenced via    `extraEnvFrom` (see examples/argocd/). | `[]` |
| extraVolumeMounts | list | Extra volume mounts on the hermes-agent container (pairs with extraVolumes). | `[]` |
| extraVolumes | list | Extra volumes on the pod, for anything the agent needs as a FILE rather    than an env var — e.g. a Secret holding a service-account JSON    (see values-google-vertex.yaml). | `[]` |
| fullnameOverride | string | Fully override the generated resource name (release-name-chart). | `""` |
| image.pullPolicy | string | Image pull policy. | `"IfNotPresent"` |
| image.repository | string | Container image repository (multi-arch: amd64 + arm64). | `"nousresearch/hermes-agent"` |
| image.tag | string | Image tag. Upstream uses DATE-based tags (e.g. "v2026.6.5" == Hermes v0.16.0), plus `latest` / `main`. There is no semver tag. Empty defaults to `.Chart.AppVersion`. | `""` |
| imagePullSecrets | list | Image pull secrets for private registries. | `[]` |
| ingress.annotations | object | Annotations to add to the Ingress (e.g. auth, cert-manager, rewrite rules). | `{}` |
| ingress.className | string | IngressClass name (e.g. "nginx", "traefik"). Empty uses the cluster default. | `""` |
| ingress.enabled | bool | Create an Ingress resource. | `false` |
| ingress.hosts | list | Host/path rules, all routed to the Service port above. | `[{"host":"hermes-agent.example.com","paths":[{"path":"/","pathType":"Prefix"}]}]` |
| ingress.tls | list | TLS configuration for the Ingress. | `[]` |
| nameOverride | string | Override the chart name used in resource names. | `""` |
| nodeSelector | object | Node selector for Pod scheduling. | `{}` |
| persistence | object | ------------------------------------------------------------------------- | `{"accessModes":["ReadWriteOnce"],"enabled":true,"existingClaim":"","mountPath":"/opt/data","size":"5Gi","storageClass":""}` |
| persistence.existingClaim | string | Use an existing PVC instead of creating a new one. When specified, the chart will use this PVC and skip creating its own. | `""` |
| persistence.storageClass | string | StorageClass for the volumeClaimTemplate. Empty = cluster default. | `""` |
| podAnnotations | object | Annotations to add to the Pod. | `{}` |
| podLabels | object | Labels to add to the Pod. | `{}` |
| podSecurityContext | object | Pod-level securityContext. Left empty by default to stay compatible with the image's s6-overlay init (which starts as root and drops privileges itself). Add hardening here once verified for your environment. | `{}` |
| probes | object | Health probes. Empty = none. The image's s6-overlay already supervises and auto-restarts the gateway in-container, so k8s probes are optional. Provide a full probe spec to enable, e.g. an exec check:   liveness:     exec: { command: ["hermes","gateway","status"] }     initialDelaySeconds: 30     periodSeconds: 30 | `{"liveness":{},"readiness":{}}` |
| probes.liveness | object | Liveness probe spec. Empty = no liveness probe. | `{}` |
| probes.readiness | object | Readiness probe spec. Empty = no readiness probe. | `{}` |
| replicaCount | int | DO NOT change this. Hermes Agent is a single-writer workload bound to one HERMES_HOME (ReadWriteOnce PVC). Raising replicaCount does NOT scale it out — with controller.type=deployment extra replicas just hang Pending (can't mount the same RWO volume); with statefulset they become separate, disconnected agent instances with their own PVC/identity. There is no supported multi-replica mode for this chart. | `1` |
| resources | object | Container resource requests/limits. Lightweight defaults aimed at small clusters (incl. Raspberry Pi / arm64). | `{"limits":{"cpu":"2","memory":"2Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| securityContext | object | Container-level securityContext. Same caveat as `podSecurityContext` above. | `{}` |
| service | object | ------------------------------------------------------------------------- | `{"annotations":{},"enabled":false,"port":9119,"type":"ClusterIP"}` |
| service.annotations | object | Annotations to add to the Service. | `{}` |
| service.enabled | bool | Create a ClusterIP Service (only useful if you expose the dashboard). | `false` |
| service.port | int | Service port (and the dashboard's container port). | `9119` |
| service.type | string | Service type. | `"ClusterIP"` |
| serviceAccount.annotations | object | Annotations to add to the ServiceAccount. | `{}` |
| serviceAccount.create | bool | Create a ServiceAccount for the pod. | `true` |
| serviceAccount.name | string | Name to use; generated from fullname when empty. | `""` |
| terminationGracePeriodSeconds | string | Pod termination grace period in seconds. Empty = Kubernetes default (30s). The gateway (image v2026.7.1+) defaults `agent.restart_drain_timeout` to 0: on stop it interrupts in-flight runs immediately, persists the transcript, and exits fast — the default grace period is plenty. If you opt into a drain window via `config.agent.restart_drain_timeout: <seconds>`, raise this WELL ABOVE that value or the kubelet SIGKILLs the gateway mid-drain (stale lock + crash loop — the same race upstream warns about with systemd's TimeoutStopSec). See "Gateway lifecycle" in the README. | `""` |
| tests | object | ------------------------------------------------------------------------- | `{"chat":{"enabled":false,"failOnError":false,"maxTurns":1,"models":[],"prompt":"Just say hi.","timeout":180},"doctorStrict":false,"doctorTimeout":120,"enabled":true,"image":{"pullPolicy":"","repository":"","tag":""},"resources":{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}}` |
| tests.chat | object | ------------------------------------------------------------------------- | `{"enabled":false,"failOnError":false,"maxTurns":1,"models":[],"prompt":"Just say hi.","timeout":180}` |
| tests.chat.enabled | bool | Run a `hermes chat` round-trip and log the conversation. | `false` |
| tests.chat.failOnError | bool | When true, a failed/empty round-trip fails the test job. | `false` |
| tests.chat.maxTurns | int | Max agent turns for the round-trip. | `1` |
| tests.chat.models | list | Optional pool of `provider/model` ids to try in order (via `hermes chat    -m <id> --provider config.model.provider`), each with its own `timeout`.    Passes as soon as one succeeds — useful for free-tier models that are    sometimes overloaded. Leave empty to use `config.model.default` as-is    (single attempt, no `-m`/`--provider` override). | `[]` |
| tests.chat.prompt | string | Prompt sent to the agent. | `"Just say hi."` |
| tests.chat.timeout | int | Seconds to allow each round-trip attempt to run before timing out. | `180` |
| tests.doctorStrict | bool | When true, `hermes doctor` issues fail the test. When false, doctor runs    for visibility but only hard checks (hermes --version, seeded config) fail. | `false` |
| tests.doctorTimeout | int | Seconds to allow `hermes doctor` to run before timing out. | `120` |
| tests.enabled | bool | Render the chart test Job. | `true` |
| tests.image | object | Image used by the test Job. Empty fields fall back to the main `image.*` (so the hermes CLI + doctor are available and arch matches). | `{"pullPolicy":"","repository":"","tag":""}` |
| tests.resources | object | Resource requests/limits for the test Job's container. | `{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| tolerations | list | Tolerations for Pod scheduling. | `[]` |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
